console.log('Server listening!');
const express = require('express');
const app = express(); //servidor
const path = require('path'); //modulo para directorios y unir los de linux windows

//configuraciones express = settings
app.set('port', 3000);
app.set('views', path.join(__dirname, 'views'));
app.engine('html', require('ejs').renderFile);
app.set('view engine', 'ejs');//motor de la vista o plantilla


//funciones que se ejecutan antes de procesar algo = middlewares


//rutas del servidor = routers
        //se mudo al index de la carpeta routes
app.use(require('./routes/index'));

//archivos estaticos css = static files
app.use(express.static(path.join(__dirname, 'public')));

//escuchando al servidor = listening
app.listen(app.get('port'), () => {
    console.log('Server on port', app.get('port'));
})
